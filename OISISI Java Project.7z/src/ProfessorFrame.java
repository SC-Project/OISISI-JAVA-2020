
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

import entitites.Professor;

public class ProfessorFrame extends JDialog {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Professor p;
	private JButton btnSubmit;
	
	private JTextField tfName;
	private JTextField tfLastName;
	private JTextField tfBirthday;
	private JTextField tfAdresa;
	private JTextField tfTelephone;
	private JTextField tfIndex;
	private JTextField tfEmail;
	private JTextField tfOffice;
	private JTextField tfTitel;
	private JTextField tfProfession;
	
	private DocumentListener doc;
	
	public ProfessorFrame(Professor prof) {

		if (prof == null) {
			p = new Professor();
		} else {
			p = prof;
		}
		setLayout(new GridLayout(11, 2));
		
		doc = new DocumentListener(){
			@Override
			public void changedUpdate(DocumentEvent arg0) {
				checkSubButton(tfName.getText(), tfLastName.getText(), tfBirthday.getText(),
						tfAdresa.getText(), tfTelephone.getText(), tfIndex.getText(),
						tfEmail.getText(), tfOffice.getText(),
						tfTitel.getText(), tfProfession.getText());

			}

			@Override
			public void insertUpdate(DocumentEvent arg0) {
				checkSubButton(tfName.getText(), tfLastName.getText(), tfBirthday.getText(),
						tfAdresa.getText(), tfTelephone.getText(), tfIndex.getText(),
						tfEmail.getText(), tfOffice.getText(),
						tfTitel.getText(), tfProfession.getText());
			}

			@Override
			public void removeUpdate(DocumentEvent arg0) {
				checkSubButton(tfName.getText(), tfLastName.getText(), tfBirthday.getText(),
						tfAdresa.getText(), tfTelephone.getText(), tfIndex.getText(),
						tfEmail.getText(), tfOffice.getText(),
						tfTitel.getText(), tfProfession.getText());
			}
		};

		JLabel lbName = new JLabel("Ime");
		tfName = new JTextField(30);
		if (prof != null) {
			tfName.setText(p.getName());
		}
		tfName.setSize(120, 30);
		tfName.getDocument().addDocumentListener(doc);
		add(lbName);
		add(tfName);

		JLabel lbLastName = new JLabel("Prezime");
		tfLastName = new JTextField(30);
		if (prof != null) {
			tfLastName.setText(p.getLastName());
		}
		tfLastName.setSize(120, 30);
		tfLastName.getDocument().addDocumentListener(doc);
		add(lbLastName);
		add(tfLastName);

		JLabel lbBirthday = new JLabel("Datum Rodjenja");
		tfBirthday = new JTextField(30);
		if (prof != null) {
			tfBirthday.setText(p.getDate());
		}
		tfBirthday.setSize(120, 30);
		tfBirthday.getDocument().addDocumentListener(doc);
		add(lbBirthday);
		add(tfBirthday);

		JLabel lbAdresa = new JLabel("Adresa stanovanja");
		tfAdresa = new JTextField(30);
		if (prof != null) {
			tfAdresa.setText(p.getAdress());
		}
		tfAdresa.setSize(120, 30);
		tfAdresa.getDocument().addDocumentListener(doc);
		add(lbAdresa);
		add(tfAdresa);

		JLabel lbTelephone = new JLabel("Broj telefona");
		tfTelephone = new JTextField(30);
		if (prof != null) {
			tfTelephone.setText(p.getTelephone());
		}
		tfTelephone.setSize(120, 30);
		tfTelephone.getDocument().addDocumentListener(doc);
		add(lbTelephone);
		add(tfTelephone);

		JLabel lbEmail = new JLabel("Email");
		tfEmail = new JTextField(30);
		if (prof != null) {
			tfEmail.setText(p.getEmail());
		}
		tfEmail.setSize(120, 30);
		tfEmail.getDocument().addDocumentListener(doc);
		add(lbEmail);
		add(tfEmail);

		JLabel lbIndex = new JLabel("ID");
		tfIndex = new JTextField(30);
		if (prof != null) {
			tfIndex.setText(p.getIdNumber());
		}
		tfIndex.setSize(120, 30);
		tfIndex.getDocument().addDocumentListener(doc);
		add(lbIndex);
		add(tfIndex);

		JLabel lbOffice = new JLabel("Kancelarija");
		tfOffice = new JTextField(30);
		if (prof != null) {
			tfOffice.setText(p.getOfficeAdress());
		}
		tfOffice.setSize(120, 30);
		tfOffice.getDocument().addDocumentListener(doc);
		add(lbOffice);
		add(tfOffice);

		JLabel lbTitel = new JLabel("Titula");
		tfTitel = new JTextField(30);
		if (prof != null) {
			tfTitel.setText(p.getTitel());
		}
		tfTitel.setSize(120, 30);
		tfTitel.getDocument().addDocumentListener(doc);
		add(lbTitel);
		add(tfTitel);

		JLabel lbProfession = new JLabel("Profesija");
		tfProfession = new JTextField(30);
		if (prof != null) {
			tfProfession.setText(p.getProfession());
		}
		tfProfession.setSize(120, 30);
		tfProfession.getDocument().addDocumentListener(doc);
		add(lbProfession);
		add(tfProfession);

		// Potvrda
		btnSubmit = new JButton("Potvrda");
		btnSubmit.setEnabled(false);
		btnSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				boolean allFine = true;

				try {
					Integer.parseInt(tfTelephone.getText());
				} catch (NumberFormatException nfe) {
					JOptionPane.showMessageDialog(null, "Morate da unesete broj u polje za Telefon");
					allFine = false;
				}

				if (allFine) {

					p.setName(tfName.getText());
					p.setLastName(tfLastName.getText());
					p.setDate(tfBirthday.getText());
					p.setAdress(tfAdresa.getText());
					p.setTelephone(tfTelephone.getText());
					p.setIdNumber(tfIndex.getText());
					p.setEmail(tfEmail.getText());
					p.setTitel(tfTitel.getText());
					p.setOfficeAdress(tfOffice.getText());
					p.setProfession(tfProfession.getText());

					setVisible(false);
				}

			}
		});
		add(btnSubmit);

		// Odustanak
		JButton cancel = new JButton("Odustanak");
		cancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				p = null;
				setVisible(false);
			}
		});
		add(cancel);

		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		int scrW = (int) screenSize.getWidth() / 2;
		int scrH = (int) screenSize.getHeight() / 2;

		setSize(scrW, scrH);
		setLocationRelativeTo(null); // to be on center
		setModal(true);// da ne mozes da selectujes nista dok ne zavrsis sa ovim

	}

	public Professor getProfessor() {
		return p;
	}

	public void setProfessor(Professor p) {
		this.p = p;
	}

	public void checkSubButton(String tfName, String tfLastName, String tfBirthday, String tfAdresa, String tfTelephone,
			String tfIndex, String tfEmail, String tfOffice, String tfTitel, String tfProfession) {

		if (tfName.equals("") || tfLastName.equals("") || tfBirthday.equals("") || tfAdresa.equals("")  || tfTelephone.equals("")  || tfIndex.equals("") 
				|| tfEmail.equals("")  || tfOffice.equals("")  || tfTitel.equals("") || tfProfession.equals("")) {
			btnSubmit.setEnabled(false);
			
		} else {
			btnSubmit.setEnabled(true);
		}
	}
}
