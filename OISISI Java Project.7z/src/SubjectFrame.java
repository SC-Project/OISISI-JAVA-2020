
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.AbstractButton;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

import entitites.Subject;

public class SubjectFrame extends JDialog {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Subject s;
	private JButton btnSubmit;
	
	private JTextField tfName;
	private JTextField tfSemesterNumber;
	private JTextField tfStudentYear;
	private JTextField tfProfessor;
	private JTextField tfIndex;
	
	private DocumentListener doc;

	public SubjectFrame(Subject sub) {

		if (sub == null) {
			s = new Subject();
		} else {
			s = sub;
		}
		setLayout(new GridLayout(6, 2));
		
		doc = new DocumentListener(){
			@Override
			public void changedUpdate(DocumentEvent arg0) {
				checkSubButton(tfName.getText(), tfSemesterNumber.getText(), tfStudentYear.getText(),
						tfProfessor.getText(), tfIndex.getText());

			}

			@Override
			public void insertUpdate(DocumentEvent arg0) {
				checkSubButton(tfName.getText(), tfSemesterNumber.getText(), tfStudentYear.getText(),
						tfProfessor.getText(), tfIndex.getText());
			}

			@Override
			public void removeUpdate(DocumentEvent arg0) {
				checkSubButton(tfName.getText(), tfSemesterNumber.getText(), tfStudentYear.getText(),
						tfProfessor.getText(), tfIndex.getText());
			}
		};

		JLabel lbIndex = new JLabel("Id");
		tfIndex = new JTextField(30);
		if (sub != null) {
			tfIndex.setText(s.getSubjectId());
		}
		tfIndex.setSize(120, 30);
		tfIndex.getDocument().addDocumentListener(doc);
		add(lbIndex);
		add(tfIndex);

		JLabel lbName = new JLabel("Naziv predmeta");
		tfName = new JTextField(30);
		if (sub != null) {
			tfName.setText(s.getName());
		}
		tfName.setSize(120, 30);
		tfName.getDocument().addDocumentListener(doc);
		add(lbName);
		add(tfName);

		JLabel lbStudentYear = new JLabel("Studentska godina");
		tfStudentYear = new JTextField(30);
		if (sub != null) {
			tfStudentYear.setText(s.getStudentYear().toString());
		}
		tfStudentYear.setSize(120, 30);
		tfStudentYear.getDocument().addDocumentListener(doc);
		add(lbStudentYear);
		add(tfStudentYear);

		JLabel lbSemesterNumber = new JLabel("Broj semestra");
		tfSemesterNumber = new JTextField(30);
		if (sub != null) {
			tfSemesterNumber.setText(s.getSemesterNumber().toString());
		}
		tfSemesterNumber.setSize(120, 30);
		tfSemesterNumber.getDocument().addDocumentListener(doc);
		add(lbSemesterNumber);
		add(tfSemesterNumber);

		JLabel lbProfessor = new JLabel("Id Profesora");
		tfProfessor = new JTextField(30);
		if (sub != null) {
			tfProfessor.setText(s.getProfessor());
		}
		tfProfessor.setSize(120, 30);

		tfProfessor.getDocument().addDocumentListener(doc);
		add(lbProfessor);
		add(tfProfessor);

		// Potvrda
		btnSubmit = new JButton("Potvrda");
		btnSubmit.setEnabled(false);
		btnSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				boolean allFine = true;

				try {
					Integer a = Integer.parseInt(tfStudentYear.getText());
					if (a > 4 || a < 1) {
						JOptionPane.showMessageDialog(null,
								"Morate da unesete broj izmedju 1 i 4 u polje studentska godina");
						allFine = false;
					}
				} catch (NumberFormatException nfe) {
					JOptionPane.showMessageDialog(null, "Morate da unesete broj u polje za studentsku godinu");
					allFine = false;
				}

				try {
					Integer semNum = Integer.parseInt(tfSemesterNumber.getText());
					Integer stYear = Integer.parseInt(tfStudentYear.getText());

					if (semNum > stYear * 2 || semNum < stYear * 2 - 1) {
						JOptionPane.showMessageDialog(null, "Morate da unesete broj " + stYear * 2 + " ili "
								+ (stYear * 2 - 1) + " u polje broj semestra");
						allFine = false;

					}
				} catch (NumberFormatException nfe) {
					JOptionPane.showMessageDialog(null, "Morate da unesete broj u polje za broj semestra");
					allFine = false;
				}

				if (allFine) {

					s.setName(tfName.getText());
					s.setSubjectId(tfIndex.getText());
					s.setStudentYear(Integer.parseInt(tfStudentYear.getText()));
					s.setSemesterNumber(Integer.parseInt(tfSemesterNumber.getText()));
					s.setProfessor(tfProfessor.getText());

					setVisible(false);
				}

			}
		});
		add(btnSubmit);

		// Odustanak
		JButton cancel = new JButton("Odustanak");
		cancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				s = null;
				setVisible(false);
			}
		});
		add(cancel);

		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		int scrW = (int) screenSize.getWidth() / 2;
		int scrH = (int) screenSize.getHeight() / 2;

		setSize(scrW, scrH);
		setLocationRelativeTo(null); // to be on center
		setModal(true);// da ne mozes da selectujes nista dok ne zavrsis sa ovim

	}

	public Subject getSubject() {
		return s;
	}

	public void setSubject(Subject s) {
		this.s = s;
	}

	public void checkSubButton(String str1, String str12, String str13, String str14,
			String str15) {

		if (str1.equals("") || str12.equals("") || str13.equals("") || str14.equals("")
				|| str15.equals("")) {
			btnSubmit.setEnabled(false);

		} else {
			btnSubmit.setEnabled(true);
		}

	}
	
	

}
