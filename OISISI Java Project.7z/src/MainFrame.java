import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.KeyStroke;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;

import entitites.Professor;
import entitites.Student;
import entitites.Subject;

public class MainFrame extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Toolbar tb;
	private StatusBar sb;
	private ArrayList<Student> studentList;
	private ArrayList<Professor> professorList;
	private ArrayList<Subject> subjectList;
	
	private Integer selectedStudentRow;
	private Integer selectedProfessorRow;
	private Integer selectedSubjectRow;

	private Student student;
	private Professor professor;
	private Subject subject;
	
	private DefaultTableModel modelStudent;
	private DefaultTableModel modelSubject;
	private DefaultTableModel modelProfessor;

	public MainFrame() {
		super("Studentska slu�ba");
		selectedStudentRow = null;
		student = new Student();

		// For window dimensions
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		int scrW = (int) screenSize.getWidth() * 3 / 4;
		int scrH = (int) screenSize.getHeight() * 3 / 4;
		;

		setSize(scrW, scrH);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // turn of app on X
		setLocationRelativeTo(null); // to be on center
		setVisible(true);

		setLayout(new BorderLayout());
		tb = new Toolbar();
		sb = new StatusBar();

		// Menu
		setJMenuBar(createMenuBar());
		// Toolabar
		add(tb, BorderLayout.NORTH);
		// StatusBar
		add(sb, BorderLayout.SOUTH);

		// CENTAR
		// TABOVI NE SMEJU DA IMAJU ISTE STVARI UNUTAR NJIH. NE SME ISTA TABELA
		// DA SE NADJE U DVA RAZLICITA TABA
		JTabbedPane tabbedPane = new JTabbedPane();

		JPanel tablePanelStudent = new JPanel();
		tablePanelStudent.setLayout(new BorderLayout());

		// Studenti u tab
		JScrollPane studentTable = getStudentTableData();
		tablePanelStudent.add(studentTable, BorderLayout.CENTER);
		tabbedPane.addTab("Studenti", tablePanelStudent);
		tabbedPane.setMnemonicAt(0, KeyEvent.VK_1); // ALT + 1

		// Profesori u tab
		JPanel tablePanelProfessor = new JPanel();
		tablePanelProfessor.setLayout(new BorderLayout());

		JScrollPane professorTable = getProfessorTableData();
		tablePanelProfessor.add(professorTable, BorderLayout.CENTER);
		tabbedPane.addTab("Profesori", tablePanelProfessor);
		tabbedPane.setMnemonicAt(1, KeyEvent.VK_2); // ALT + 2

		// Predmeti u tab
		JPanel tablePanelSubject = new JPanel();
		tablePanelSubject.setLayout(new BorderLayout());

		JScrollPane subjectTable = getSubjectTableData();
		subjectTable.addMouseListener(new MouseAdapter() { 
	          public void mousePressed(MouseEvent me) { 
	              tb.setActiveTable(1);
	            } 
	          }); 
		tablePanelSubject.add(subjectTable, BorderLayout.CENTER);
		tabbedPane.addTab("Predmeti", tablePanelSubject);
		tabbedPane.setMnemonicAt(2, KeyEvent.VK_3); // ALT + 3

		add(tabbedPane, BorderLayout.CENTER);

		// Prosledjivanje referenca u toolbar
		tb.setStudentsModel(modelStudent);
		tb.setStudentList(studentList);
		
		tb.setProfessorsModel(modelProfessor);
		tb.setProfessorList(professorList);
		
		tb.setSubjectsModel(modelSubject);
		tb.setSubjectList(subjectList);

	}

	private JMenuBar createMenuBar() {
		JMenuBar menuBar = new JMenuBar();

		// New
		JMenu newMenu = new JMenu("New");
		newMenu.setMnemonic(KeyEvent.VK_N);
		JMenuItem newItem = new JMenuItem("New");
		newItem.setMnemonic(KeyEvent.VK_W);
		newItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_W, ActionEvent.CTRL_MASK));
		newItem.setIcon(new ImageIcon("pictures/addBtn2.png"));

		newItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent evt) {
				tb.addElement();
			}
		});

		// Close
		JMenuItem closeItem = new JMenuItem("Close");
		closeItem.setMnemonic(KeyEvent.VK_C);
		closeItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_C, ActionEvent.CTRL_MASK));
		closeItem.setIcon(new ImageIcon("pictures/closeIcon2.png"));
		closeItem.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent evt) {
				System.exit(0);
			}
		});

		newMenu.add(newItem);
		newMenu.add(closeItem);

		// Edit
		JMenu editMenu = new JMenu("Edit");
		editMenu.setMnemonic(KeyEvent.VK_E);
		JMenuItem editItem = new JMenuItem("Edit");
		editItem.setMnemonic(KeyEvent.VK_E);
		editItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_E, ActionEvent.CTRL_MASK));
		editItem.setIcon(new ImageIcon("pictures/editBtn2.png"));

		editItem.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent evt) {
				tb.editElement();
			}
		});

		// Delete
		JMenuItem deleteItem = new JMenuItem("Delete");
		deleteItem.setMnemonic(KeyEvent.VK_D);
		deleteItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_D, ActionEvent.CTRL_MASK));
		deleteItem.setIcon(new ImageIcon("pictures/deleteBtn3.png"));

		deleteItem.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent evt) {
				tb.deleteElement();
			}
		});

		editMenu.add(editItem);
		editMenu.add(deleteItem);

		// Help
		JMenu helpMenu = new JMenu("Help");
		helpMenu.setMnemonic(KeyEvent.VK_H);
		JMenuItem helpItem = new JMenuItem("Help");
		helpItem.setMnemonic(KeyEvent.VK_H);
		helpItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_H, ActionEvent.CTRL_MASK));
		helpItem.setIcon(new ImageIcon("pictures/helpIcon2.png"));
		helpItem.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent evt) {
				HelpFrame hf = new HelpFrame();
				hf.setVisible(true);
			}
		});

		// About
		JMenuItem aboutItem = new JMenuItem("About");
		aboutItem.setMnemonic(KeyEvent.VK_A);
		aboutItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_A, ActionEvent.CTRL_MASK));
		aboutItem.setIcon(new ImageIcon("pictures/aboutIcon2.png"));
		aboutItem.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent evt) {
				AboutFrame af = new AboutFrame();
				af.setVisible(true);
			}
		});

		helpMenu.add(helpItem);
		helpMenu.add(aboutItem);

		// final menu
		menuBar.add(newMenu);
		menuBar.add(editMenu);
		menuBar.add(helpMenu);

		return menuBar;
	}


	private JScrollPane getStudentTableData() {

		modelStudent = new DefaultTableModel();
		JTable jt = new JTable(modelStudent) {
			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;

			// da se ne moze rucno izmeniti na tabeli nego mora preko dialoga
			public boolean isCellEditable(int row, int column) {
				return false;
			}

			public Component prepareRenderer(TableCellRenderer r, int row, int column) {
				Component c = super.prepareRenderer(r, row, column);

				if (row % 2 == 0) {
					c.setBackground(Color.WHITE);
				} else {
					c.setBackground(Color.LIGHT_GRAY);
				}

				if (isCellSelected(row, column)) {
					c.setBackground(Color.GREEN);
				}

				return c;
			}
		};

		// Dodavanje kolona
		String column[] = { "Index", "Name", "Last Name", "Birthday", "Adress", "Telephone", "Email", "Starting Date",
				"Student Year", "Status", "Avg Mark" };
		for (String s : column) {
			modelStudent.addColumn(s);
		}

		try (BufferedReader br = new BufferedReader(new FileReader("Lists/Students"))) {
			String line;
			studentList = new ArrayList<Student>();
			while ((line = br.readLine()) != null) {
				if (line.contains("[") && line.contains("]") && line.contains(",")) {
					String[] strArray = line.split("\\[")[1].split("\\]")[0].split(",");

					Student s = new Student();
					for (int i = 0; i < strArray.length; i++) {
						switch (i) {
						case 0: {
							s.setName(strArray[i].split("=")[1]);
							break;
						}
						case 1: {
							s.setLastName(strArray[i].split("=")[1]);
							break;
						}
						case 2: {
							s.setDate(strArray[i].split("=")[1]);
							break;
						}
						case 3: {
							s.setAdress(strArray[i].split("=")[1]);
							break;
						}
						case 4: {
							s.setTelephone(strArray[i].split("=")[1]);
							break;
						}
						case 5: {
							s.setEmail(strArray[i].split("=")[1]);
							break;
						}
						case 6: {
							s.setIndex(strArray[i].split("=")[1]);
							break;
						}
						case 7: {
							s.setStartDate(Integer.parseInt((strArray[i].split("=")[1])));
							break;
						}
						case 8: {
							s.setStudentYear(Integer.parseInt((strArray[i].split("=")[1])));
							break;
						}
						case 9: {
							s.setStatus(strArray[i].split("=")[1]);
							break;
						}
						case 10: {
							s.setAvgMark(Double.parseDouble(strArray[i].split("=")[1]));
							break;
						}

						}// end switch

						
					} //end for
					
					studentList.add(s);
					modelStudent.addRow(new Object[] {s.getIndex(), s.getName(), s.getLastName(), s.getDate(), s.getAdress(),
							s.getTelephone(), s.getEmail(), s.getStartDate(), s.getStudentYear(), s.getStatus(),
							s.getAvgMark()});

				}// if validation

			}// end while
		} catch (Exception e) {
			System.err.println("Problem while reading the file Students");
		}

		jt.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				selectedStudentRow = jt.getSelectedRow();
				setSelectedRowStudent(selectedStudentRow);

			}
		});

		jt.setBounds(30, 40, 200, 300);
		jt.setAutoCreateRowSorter(true);// za opciono sortiranje
		JScrollPane studentTable = new JScrollPane(jt);
		return studentTable;
	}
	
	private JScrollPane getProfessorTableData() {

		modelProfessor = new DefaultTableModel();
		JTable jt = new JTable(modelProfessor) {
			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;

			// da se ne moze rucno izmeniti na tabeli nego mora preko dialoga
			public boolean isCellEditable(int row, int column) {
				return false;
			}

			public Component prepareRenderer(TableCellRenderer r, int row, int column) {
				Component c = super.prepareRenderer(r, row, column);

				if (row % 2 == 0) {
					c.setBackground(Color.WHITE);
				} else {
					c.setBackground(Color.LIGHT_GRAY);
				}

				if (isCellSelected(row, column)) {
					c.setBackground(Color.GREEN);
				}

				return c;
			}
		};
		
		// Dodavanje kolona
		String column[] = { "Id", "Name", "Last Name", "Birthday", "Adress", "Telephone", "Email", 
				"Office Adress", "Titel", "Profession" };
		
		for (String s : column) {
			modelProfessor.addColumn(s);
		}

		try (BufferedReader br = new BufferedReader(new FileReader("Lists/Professors"))) {
			String line;
			professorList = new ArrayList<Professor>();
			while ((line = br.readLine()) != null) {
				if (line.contains("[") && line.contains("]") && line.contains(",")) {
					String[] strArray = line.split("\\[")[1].split("\\]")[0].split(",");

					Professor p = new Professor();
					for (int i = 0; i < strArray.length; i++) {
						switch (i) {
							case 0: {
								p.setName(strArray[i].split("=")[1]);
								break;
							}
							case 1: {
								p.setLastName(strArray[i].split("=")[1]);
								break;
							}
							case 2: {
								p.setDate(strArray[i].split("=")[1]);
								break;
							}
							case 3: {
								p.setAdress(strArray[i].split("=")[1]);
								break;
							}
							case 4: {
								p.setTelephone(strArray[i].split("=")[1]);
								break;
							}
							case 5: {
								p.setEmail(strArray[i].split("=")[1]);
								break;
							}
							case 6: {
								p.setOfficeAdress(strArray[i].split("=")[1]);
								break;
							}
							case 7: {
								p.setIdNumber((strArray[i].split("=")[1]));
								break;
							}
							case 8: {
								p.setTitel((strArray[i].split("=")[1]));
								break;
							}
							case 9: {
								p.setProfession(strArray[i].split("=")[1]);
								break;
							}
						}// end switch
					} //end for
					
					professorList.add(p);
					modelProfessor.addRow(new Object[] {p.getIdNumber(), p.getName(), p.getLastName(), p.getDate(), p.getAdress(),
							p.getTelephone(), p.getEmail(), p.getOfficeAdress(), p.getTitel(),p.getProfession()	});

				}// if validation

			}// end while
		} catch (Exception e) {
			System.err.println("Problem while reading the file Professors");
		}

		jt.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				selectedProfessorRow = jt.getSelectedRow();
				setSelectedRowProfessor(selectedProfessorRow);

			}
		});

		jt.setBounds(30, 40, 200, 300);
		jt.setAutoCreateRowSorter(true);// za opciono sortiranje
		JScrollPane professorTable = new JScrollPane(jt);
		return professorTable;
	}
	
	

	private JScrollPane getSubjectTableData() {

		modelSubject = new DefaultTableModel();
		JTable jt = new JTable(modelSubject) {
			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;

			// da se ne moze rucno izmeniti na tabeli nego mora preko dialoga
			public boolean isCellEditable(int row, int column) {
				return false;
			}

			public Component prepareRenderer(TableCellRenderer r, int row, int column) {
				Component c = super.prepareRenderer(r, row, column);

				if (row % 2 == 0) {
					c.setBackground(Color.WHITE);
				} else {
					c.setBackground(Color.LIGHT_GRAY);
				}

				if (isCellSelected(row, column)) {
					c.setBackground(Color.GREEN);
				}

				return c;
			}
		};
		
		
		// Dodavanje kolona
		String column[] = { "Subject Id", "Name", "Semestar Number", "Student Year", "Professor Id"};
		
		for (String s : column) {
			modelSubject.addColumn(s);
		}

		try (BufferedReader br = new BufferedReader(new FileReader("Lists/Subjects"))) {
			String line;
			subjectList = new ArrayList<Subject>();
			while ((line = br.readLine()) != null) {
				if (line.contains("[") && line.contains("]") && line.contains(",")) {
					String[] strArray = line.split("\\[")[1].split("\\]")[0].split(",");

					Subject s = new Subject();
					for (int i = 0; i < strArray.length; i++) {
						switch (i) {
							case 0: {
								s.setSubjectId(strArray[i].split("=")[1]);
								break;
							}
							case 1: {
								s.setName(strArray[i].split("=")[1]);
								break;
							}
							case 2: {
								s.setSemesterNumber(Integer.parseInt((strArray[i].split("=")[1])));
								break;
							}
							case 3: {
								s.setStudentYear(Integer.parseInt(strArray[i].split("=")[1]));
								break;
							}
							case 4: {
								s.setProfessor(strArray[i].split("=")[1]);
								break;
							}
						}// end switch
					} //end for
					
					subjectList.add(s);
					modelSubject.addRow(new Object[] {s.getSubjectId(), s.getName(), s.getSemesterNumber(), s.getStudentYear(), s.getProfessor()	});

				}// if validation

			}// end while
		} catch (Exception e) {
			System.err.println("Problem while reading the file Subjects");
		}

		jt.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				selectedSubjectRow = jt.getSelectedRow();
				setSelectedRowSubject(selectedSubjectRow);

			}
		});

		jt.setBounds(30, 40, 200, 300);
		jt.setAutoCreateRowSorter(true);// za opciono sortiranje
		JScrollPane professorTable = new JScrollPane(jt);
		return professorTable;
	}

	public ArrayList<Student> getStudentList() {
		return studentList;
	}

	public void setStudentList(ArrayList<Student> studentList) {
		this.studentList = studentList;
	}

	public ArrayList<Professor> getProfessorList() {
		return professorList;
	}

	public void setProfessorList(ArrayList<Professor> professorList) {
		this.professorList = professorList;
	}

	public ArrayList<Subject> getSubjectList() {
		return subjectList;
	}

	public void setSubjectList(ArrayList<Subject> subjectList) {
		this.subjectList = subjectList;
	}

	public void setSelectedRowStudent(int row) {
		selectedStudentRow = row;
		String index = (String) modelStudent.getValueAt(row, 0);

		if (studentList != null) {
			for (Student s : studentList) {
				if (s.getIndex().equals(index)) {
					student = s;
				}
			}
		} else {
			System.out.println("listStudent is empty");
		}

		tb.setSelectedStudent(student);
		tb.setSelectedRowStudent(row);
		tb.setActiveTable(1);
	}
	
	public void setSelectedRowProfessor(int row) {
		selectedProfessorRow = row;
		String index = (String) modelProfessor.getValueAt(row, 0);

		if (professorList != null) {
			for (Professor p : professorList) {
				if (p.getIdNumber().equals(index)) {
					professor = p;
				}
			}
		} else {
			System.out.println("listProfessor is empty");
		}

		tb.setSelectedProfessor(professor);
		tb.setSelectedRowProfessor(row);
		tb.setActiveTable(2);

	}
	
	public void setSelectedRowSubject(int row) {
		selectedSubjectRow = row;
		String index = (String) modelSubject.getValueAt(row, 0);

		if (subjectList != null) {
			for (Subject s : subjectList) {
				if (s.getSubjectId().equals(index)) {
					subject = s;
				}
			}
		} else {
			System.out.println("listSubject is empty");
		}

		tb.setSelectedSubject(subject);
		tb.setSelectedRowSubject(row);
		tb.setActiveTable(3);

	}
}
