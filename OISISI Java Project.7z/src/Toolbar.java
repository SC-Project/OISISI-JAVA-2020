import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.BevelBorder;
import javax.swing.table.DefaultTableModel;

import entitites.Professor;
import entitites.Student;
import entitites.Subject;

public class Toolbar extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JButton addBtn;
	private JButton editBtn;
	private JButton deleteBtn;
	private JButton searchBtn;
	private JButton saveBtn;
	private JButton restoreBtn;
	private JTextField text;

	private StudentFrame sf;
	private ProfessorFrame pf;
	private SubjectFrame subf;

	private Student student;
	private Professor professor;
	private Subject subject;

	private ArrayList<Student> listStudent = new ArrayList<Student>();
	private ArrayList<Professor> listProfessor = new ArrayList<Professor>();
	private ArrayList<Subject> listSubject = new ArrayList<Subject>();

	private DefaultTableModel modelStudent;
	private Integer selectedStudentRow;

	private DefaultTableModel modelProfessor;
	private Integer selectedProfessorRow;

	private DefaultTableModel modelSubject;
	private Integer selectedSubjectRow;

	private Integer activeTable;

	private ArrayList<Student> backupListStudent = listStudent;
	private DefaultTableModel BackupModelStudent = modelStudent;

	private ArrayList<Professor> backupListProfessor = listProfessor;
	private DefaultTableModel BackupModelProfessor = modelProfessor;

	private ArrayList<Subject> backupListSubject = listSubject;
	private DefaultTableModel BackupModelSubject = modelSubject;

	public Toolbar() {

		sf = new StudentFrame(null);
		pf = new ProfessorFrame(null);
		subf = new SubjectFrame(null);
		activeTable = 0;

		setLayout(new BorderLayout());
		setBorder(new BevelBorder(BevelBorder.LOWERED));

		JPanel p = new JPanel();
		p.setLayout(new FlowLayout(FlowLayout.LEFT));
		// Add
		BufferedImage buttonIcon;
		try {
			buttonIcon = ImageIO.read(new File("pictures/addBtn.png"));
			Image newImage = buttonIcon.getScaledInstance(30, 30, Image.SCALE_SMOOTH);
			addBtn = new JButton(new ImageIcon(newImage));
			addBtn.setBorder(BorderFactory.createEmptyBorder());
			addBtn.setContentAreaFilled(false);
			addBtn.setToolTipText("Dodaje novi entitet za tabelu");

			addBtn.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent evt) {
					addElement();
				}
			});

		} catch (IOException e) {
			e.printStackTrace();
			System.err.println("Problems with finding or resizeing the ADD picture");
		}

		// Edit
		try {
			buttonIcon = ImageIO.read(new File("pictures/editBtn.png"));
			Image newImage = buttonIcon.getScaledInstance(30, 30, Image.SCALE_SMOOTH);
			editBtn = new JButton(new ImageIcon(newImage));
			editBtn.setBorder(BorderFactory.createEmptyBorder());
			editBtn.setContentAreaFilled(false);
			editBtn.setToolTipText("Podesava selektovani entitet");

			editBtn.addActionListener(new ActionListener() {

	@Override
				public void actionPerformed(ActionEvent evt) {
					editElement();
				}});}catch(

	IOException e)
	{
		e.printStackTrace();
		System.err.println("Problems with finding or resizeing the EDIT picture");
	}

	// Delete
	try
	{
		buttonIcon = ImageIO.read(new File("pictures/deleteBtn.png"));
		Image newImage = buttonIcon.getScaledInstance(30, 30, Image.SCALE_SMOOTH);
		deleteBtn = new JButton(new ImageIcon(newImage));
		deleteBtn.setBorder(BorderFactory.createEmptyBorder());
		deleteBtn.setContentAreaFilled(false);
		deleteBtn.setToolTipText("Brise selektovani entitet");

		deleteBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent evt) {
				deleteElement();
			}
		});
	}catch(
	IOException e)
	{
			e.printStackTrace();
			System.err.println("Problems with finding or resizeing the DELETE picture");
		}

	p.add(addBtn,BorderLayout.WEST);p.add(editBtn,BorderLayout.WEST);p.add(deleteBtn,BorderLayout.WEST);

	////////////////////////////////////////////

	try
	{
		buttonIcon = ImageIO.read(new File("pictures/saveBtn.png"));
		Image newImage = buttonIcon.getScaledInstance(30, 30, Image.SCALE_SMOOTH);
		saveBtn = new JButton(new ImageIcon(newImage));
		saveBtn.setBorder(BorderFactory.createEmptyBorder());
		saveBtn.setContentAreaFilled(false);
		saveBtn.setToolTipText("Sacuva sadrzaj svih tabela");

		saveBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent evt) {
				saveFiles();
			}
		});
	}catch(
	IOException e)
	{
		e.printStackTrace();
		System.err.println("Problems with finding or resizeing the DELETE picture");
	}

	p.add(saveBtn,BorderLayout.WEST);
	//////////////////////////////////////////////

	add(p, BorderLayout.WEST);

		// right side
		p = new JPanel();
		p.setLayout(new FlowLayout(FlowLayout.RIGHT));
		text = new JTextField(30);
		text.setSize(120, 30);
		p.add(text);

		try {
			buttonIcon = ImageIO.read(new File("pictures/searchBtn.png"));
			Image newImage = buttonIcon.getScaledInstance(30, 30, Image.SCALE_SMOOTH);
			searchBtn = new JButton(new ImageIcon(newImage));
			searchBtn.setBorder(BorderFactory.createEmptyBorder());
			searchBtn.setContentAreaFilled(false);

			searchBtn.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent evt) {
					searchTables(text.getText());
				}
			});

			p.add(searchBtn);
		} catch (IOException e) {
			e.printStackTrace();
			System.err.println("Problems with finding or resizeing the DELETE picture");
		}

		add(p, BorderLayout.EAST);

		/////////////////////////////////////////////////////////////////////////
		// Restore Table to original

		try {
			buttonIcon = ImageIO.read(new File("pictures/restoreBtn.jpg"));
			Image newImage = buttonIcon.getScaledInstance(30, 30, Image.SCALE_SMOOTH);
			restoreBtn = new JButton(new ImageIcon(newImage));
			restoreBtn.setBorder(BorderFactory.createEmptyBorder());
			restoreBtn.setContentAreaFilled(false);
			restoreBtn.setToolTipText("Resetuje sve tabele");

			restoreBtn.addActionListener(new ActionListener() {

	@Override
	public void actionPerformed(ActionEvent evt) {
		resetTables();
	}});}catch(

	IOException e)
	{
			e.printStackTrace();
			System.err.println("Problems with finding or resizeing the DELETE picture");
		}

	p.add(restoreBtn,BorderLayout.WEST);

	}

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	public Professor getProfessor() {
		return professor;
	}

	public void setProfessor(Professor professor) {
		this.professor = professor;
	}

	public Subject getSubject() {
		return subject;
	}

	public void setSubject(Subject subject) {
		this.subject = subject;
	}

	public ArrayList<Student> getListStudent() {
		return listStudent;
	}

	public void setListStudent(ArrayList<Student> listStudent) {
		this.listStudent = listStudent;
	}

	public ArrayList<Professor> getListProfessor() {
		return listProfessor;
	}

	public void setListProfessor(ArrayList<Professor> listProfessor) {
		this.listProfessor = listProfessor;
	}

	public ArrayList<Subject> getListSubject() {
		return listSubject;
	}

	public void setListSubject(ArrayList<Subject> listSubject) {
		this.listSubject = listSubject;
	}

	// Setting the student model and student list
	public void setStudentsModel(DefaultTableModel modelStudent) {
		this.modelStudent = modelStudent;

	}

	// and student list
	public void setStudentList(ArrayList<Student> studentList) {
		this.listStudent = studentList;

	}

	// Setting the Professor model and professor list
	public void setProfessorsModel(DefaultTableModel modelProfessor) {
		this.modelProfessor = modelProfessor;

	}

	// and Professor list
	public void setProfessorList(ArrayList<Professor> professorList) {
		this.listProfessor = professorList;

	}

	// Setting the Subject model and Subject list
	public void setSubjectsModel(DefaultTableModel modelSubject) {
		this.modelSubject = modelSubject;

	}

	// and Subject list
	public void setSubjectList(ArrayList<Subject> subjectList) {
		this.listSubject = subjectList;

	}

	// Kada se selektuje red u student tabeli
	public void setSelectedRowStudent(int row) {
		selectedStudentRow = row;
	}

	public void setSelectedStudent(Student s) {
		student = s;
	}

	// Kada se selektuje red u profesor tabeli
	public void setSelectedRowProfessor(int row) {
		selectedProfessorRow = row;
	}

	public void setSelectedProfessor(Professor p) {
		professor = p;
	}

	// Kada se selektuje red u predmet tabeli
	public void setSelectedRowSubject(int row) {
		selectedSubjectRow = row;
	}

	public void setSelectedSubject(Subject s) {
		subject = s;
	}

	public Integer getActiveTable() {
		return activeTable;
	}

	public void setActiveTable(Integer activeTable) {
		this.activeTable = activeTable;
	}

	void saveFiles() {
		PrintWriter writer;
		try {
			writer = new PrintWriter("Lists/Students", "UTF-8");
			Student s = new Student();
			for (int i = 0; i < listStudent.size(); i++) {
				System.out.println(listStudent.get(i));
				s = listStudent.get(i);
				writer.println(s.toString());
			}
			writer.close();

			writer = new PrintWriter("Lists/Professors", "UTF-8");
			Professor p = new Professor();
			for (int i = 0; i < listProfessor.size(); i++) {
				System.out.println(listProfessor.get(i));
				p = listProfessor.get(i);
				writer.println(p.toString());
			}
			writer.close();

			writer = new PrintWriter("Lists/Subjects", "UTF-8");
			Subject su = new Subject();
			for (int i = 0; i < listSubject.size(); i++) {
				System.out.println(listSubject.get(i));
				su = listSubject.get(i);
				writer.println(su.toString());
			}
			writer.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}

	}

	public void addElement() {
		if (activeTable == 1) {
			sf = new StudentFrame(null);
			sf.setVisible(true);

			// recive Student
			student = sf.getStudent();
			if (student != null) {
				listStudent.add(student);
				modelStudent.addRow(new Object[] { student.getIndex(), student.getName(), student.getLastName(),
						student.getDate(), student.getAdress(), student.getTelephone(), student.getEmail(),
						student.getStartDate().toString(), student.getStudentYear().toString(), student.getStatus(),
						student.getAvgMark().toString() });
			}
		} else if (activeTable == 2) {
			pf = new ProfessorFrame(null);
			pf.setVisible(true);

			// recive Professor
			professor = pf.getProfessor();
			if (professor != null) {
				listProfessor.add(professor);
				modelProfessor.addRow(new Object[] { professor.getIdNumber(), professor.getName(),
						professor.getLastName(), professor.getDate(), professor.getAdress(), professor.getTelephone(),
						professor.getEmail(), professor.getOfficeAdress(), professor.getTitel(),
						professor.getProfession() });
			}
		} else if (activeTable == 3) {
			subf = new SubjectFrame(null);
			subf.setVisible(true);

			// recive subject
			subject = subf.getSubject();
			if (subject != null) {
				listSubject.add(subject);
				modelSubject.addRow(new Object[] { subject.getSubjectId(), subject.getName(),
						subject.getSemesterNumber(), subject.getStudentYear(), subject.getProfessor() });
			}
		}
	}

	public void editElement() {
		if (activeTable == 1) {
			if (selectedStudentRow != null) {
				sf = new StudentFrame(student);
				sf.setVisible(true);

				// recive Student

				student = sf.getStudent();

				ArrayList<Student> newList = new ArrayList<Student>();
				for (int i = 0; i < listStudent.size(); i++) {
					if (i == selectedStudentRow) {
						newList.add(student);
					} else {
						newList.add(listStudent.get(i));
					}
				}

				listStudent = newList;

				modelStudent.removeRow(selectedStudentRow);
				modelStudent.insertRow(selectedStudentRow,
						new Object[] { student.getIndex(), student.getName(), student.getLastName(), student.getDate(),
								student.getAdress(), student.getTelephone(), student.getEmail(), student.getStartDate(),
								student.getStudentYear(), student.getStatus(), student.getAvgMark() });

				selectedStudentRow = null;

			} else {
				JOptionPane.showMessageDialog(null, "Morate prvo da selektujete jednog Studenta!");
			}
		} else if (activeTable == 2) {
			if (selectedProfessorRow != null) {
				pf = new ProfessorFrame(professor);
				pf.setVisible(true);

				// recive Profesor

				professor = pf.getProfessor();

				ArrayList<Professor> newList = new ArrayList<Professor>();
				for (int i = 0; i < listProfessor.size(); i++) {
					if (i == selectedProfessorRow) {
						newList.add(professor);
					} else {
						newList.add(listProfessor.get(i));
					}
				}

				listProfessor = newList;

				modelProfessor.removeRow(selectedProfessorRow);
				modelProfessor.insertRow(selectedProfessorRow,
						new Object[] { professor.getIdNumber(), professor.getName(), professor.getLastName(),
								professor.getDate(), professor.getAdress(), professor.getTelephone(),
								professor.getEmail(), professor.getOfficeAdress(), professor.getTitel(),
								professor.getProfession() });

				selectedProfessorRow = null;

			} else {
				JOptionPane.showMessageDialog(null, "Morate prvo da selektujete jednog Profesora!");
			}
		} else if (activeTable == 3) {
			if (selectedSubjectRow != null) {
				subf = new SubjectFrame(subject);
				subf.setVisible(true);

				// recive Subject

				subject = subf.getSubject();

				ArrayList<Subject> newList = new ArrayList<Subject>();
				for (int i = 0; i < listSubject.size(); i++) {
					if (i == selectedSubjectRow) {
						newList.add(subject);
					} else {
						newList.add(listSubject.get(i));
					}
				}

				listSubject = newList;

				modelSubject.removeRow(selectedSubjectRow);
				modelSubject.insertRow(selectedSubjectRow, new Object[] { subject.getSubjectId(), subject.getName(),
						subject.getSemesterNumber(), subject.getStudentYear(), subject.getProfessor() });

				selectedSubjectRow = null;
			} else {
				JOptionPane.showMessageDialog(null, "Morate prvo da selektujete jedan Predmet!");
			}
		}
	}

	public void deleteElement() {
		if (activeTable == 1) {
			if (selectedStudentRow != null) {
				int input = JOptionPane.showConfirmDialog(null, "Are you sure?");
				if (input == 0) {
					ArrayList<Student> newList = new ArrayList<Student>();
					for (int i = 0; i < listStudent.size(); i++) {
						if (i != selectedStudentRow) {
							newList.add(listStudent.get(i));
							System.out.println(listStudent.get(i));
						}
					}
					listStudent = newList;
					modelStudent.removeRow(selectedStudentRow);

					selectedStudentRow = null;
				}
			} else {
				JOptionPane.showMessageDialog(null, "Morate prvo da selektujete nesto!");
			}
		} else if (activeTable == 2) {
			if (selectedProfessorRow != null) {
				int input = JOptionPane.showConfirmDialog(null, "Are you sure?");
				if (input == 0) {
					ArrayList<Professor> newList = new ArrayList<Professor>();
					for (int i = 0; i < listProfessor.size(); i++) {
						if (i != selectedProfessorRow) {
							newList.add(listProfessor.get(i));
						}
					}
					listProfessor = newList;
					modelProfessor.removeRow(selectedProfessorRow);
					selectedProfessorRow = null;
				}
			} else {
				JOptionPane.showMessageDialog(null, "Morate prvo da selektujete nesto!");
			}
		} else if (activeTable == 3) {
			if (selectedSubjectRow != null) {
				int input = JOptionPane.showConfirmDialog(null, "Are you sure?");
				if (input == 0) {
					ArrayList<Subject> newList = new ArrayList<Subject>();
					for (int i = 0; i < listSubject.size(); i++) {
						if (i != selectedSubjectRow) {
							newList.add(listSubject.get(i));
						}
					}
					listSubject = newList;
					modelSubject.removeRow(selectedSubjectRow);
					selectedSubjectRow = null;
				}
			} else {
				JOptionPane.showMessageDialog(null, "Morate prvo da selektujete nesto!");
			}
		}
	}

	@SuppressWarnings("null")
	public void searchTables(String text) {
		resetTables();
		if (activeTable == 1) {
			if (text != null || !text.equals("")) {
				backupListStudent = listStudent;
				BackupModelStudent = modelStudent;

				String[] strArray = null;
				if (text.indexOf(";") != 0) {
					strArray = text.split(";");
				} else {
					strArray[0] = text;
				}

				ArrayList<Student> newStudentList = listStudent;

				for (int i = 0; i < strArray.length; i++) {
					newStudentList = generateList(newStudentList, strArray[i]);
				}
					// listStudent = newStudentList;
				updateStudentModel(newStudentList);
				System.out.println("End newStudentList size = " + newStudentList.size());
			} // end if
			

		} else if (activeTable == 2)

		{

		} else if (activeTable == 3) {

		}

	}

	private ArrayList<Student> generateList(ArrayList<Student> newStudentList, String strArray) {
		

		String field = "";
		String content = "";

		ArrayList<Student> tmpList = new ArrayList<Student>();
		
		if (strArray.indexOf("=") != 0) {
			field = strArray.split("=")[0].toLowerCase();
			content = strArray.split("=")[1];
			tmpList = new ArrayList<Student>();
			System.out.println("newStudentList size: " + newStudentList.size());
			System.out.println("Polje: " + field + " Sadrzaj: " + content );
			switch (field) {
				case "index": {
					for (int j = 0; j < newStudentList.size(); j++) {
						if (newStudentList.get(j).getIndex().equals(content)) {
							tmpList.add(newStudentList.get(j));
						}
					}
					newStudentList = tmpList;
					break;

				}

				case "name": {
					for (int j = 0; j < newStudentList.size(); j++) {
						if (newStudentList.get(j).getName().equals(content)) {
							tmpList.add(newStudentList.get(j));
						}
					}
					newStudentList = tmpList;
					break;

				}
				case "lastname": {
					for (int j = 0; j < newStudentList.size(); j++) {
						if (newStudentList.get(j).getLastName().equals(content)) {
							tmpList.add(newStudentList.get(j));
						}
					}
					newStudentList = tmpList;
					break;

				}
				case "adress": {
					for (int j = 0; j < newStudentList.size(); j++) {
						if (newStudentList.get(j).getAdress().equals(content)) {
							tmpList.add(newStudentList.get(j));
						}
					}
					newStudentList = tmpList;
					break;

				}
				case "birthday": {
					for (int j = 0; j < newStudentList.size(); j++) {
						if (newStudentList.get(j).getDate().equals(content)) {
							tmpList.add(newStudentList.get(j));
						}
					}
					newStudentList = tmpList;
					break;

				}
				case "telephone": {
					for (int j = 0; j < newStudentList.size(); j++) {
						if (newStudentList.get(j).getTelephone().equals(content)) {
							tmpList.add(newStudentList.get(j));
						}
					}
					newStudentList = tmpList;
					break;

				}
				case "email": {
					for (int j = 0; j < newStudentList.size(); j++) {
						if (newStudentList.get(j).getEmail().equals(content)) {
							tmpList.add(newStudentList.get(j));
						}
					}
					newStudentList = tmpList;
					break;

				}
				case "startingdate": {
					for (int j = 0; j < newStudentList.size(); j++) {
						if (newStudentList.get(j).getStartDate().equals(content)) {
							tmpList.add(newStudentList.get(j));
						}
					}
					newStudentList = tmpList;
					break;

				}
				case "studentyear": {
					for (int j = 0; j < newStudentList.size(); j++) {
						if (newStudentList.get(j).getStudentYear().equals(content)) {
							tmpList.add(newStudentList.get(j));
						}
					}
					newStudentList = tmpList;
					break;

				}
				case "status": {
					for (int j = 0; j < newStudentList.size(); j++) {
						if (newStudentList.get(j).getStatus().equals(content)) {
							tmpList.add(newStudentList.get(j));
						}
					}
					newStudentList = tmpList;
					break;

				}
				case "avgmark": {
					for (int j = 0; j < newStudentList.size(); j++) {
						if (newStudentList.get(j).getAvgMark().equals(content)) {
							tmpList.add(newStudentList.get(j));
						}
					}
					newStudentList = tmpList;
					break;

				}

			}// end switch
		}//end for
		return newStudentList;
	}

	private void updateStudentModel(ArrayList<Student> newStudentList) {

		if (listStudent.size() > 0) {
			for (int i = 0; i < listStudent.size(); i++) {
				try {
					modelStudent.removeRow(0);
				} catch (Exception e) {

				}
			}

			for (Student s : newStudentList) {
				modelStudent.addRow(new Object[] { s.getIndex(), s.getName(), s.getLastName(), s.getDate(),
						s.getAdress(), s.getTelephone(), s.getEmail(), s.getStartDate(), s.getStudentYear(),
						s.getStatus(), s.getAvgMark() });
			}
		}

	}

	private void resetTables() {
		
		text.setText("");
		for (int i = 0; i < listStudent.size(); i++) {
			try {
				modelStudent.removeRow(0);
			} catch (Exception e) {
			}
		}
		for (Student s : listStudent) {
			modelStudent.addRow(new Object[] { s.getIndex(), s.getName(), s.getLastName(), s.getDate(), s.getAdress(),
					s.getTelephone(), s.getEmail(), s.getStartDate(), s.getStudentYear(), s.getStatus(),
					s.getAvgMark() });
		}
	}

	private ArrayList<Student> checkForCopy(ArrayList<Student> tmpList, ArrayList<Student> newStudentList) {
		if (newStudentList == null || newStudentList.size() == 0) {
			newStudentList = tmpList;
		} else {
			boolean copy = false;
			for (int j = 0; j < tmpList.size(); j++) {
				copy = false;
				for (int k = 0; k < newStudentList.size(); k++) {
					if (tmpList.get(j).getIndex().equals(newStudentList.get(k).getIndex())) {
						copy = true; // vec ima isti u listi
						break;
					}
				}
				if (!copy) {
					newStudentList.add(tmpList.get(j));
				}
			}
		}
		return newStudentList;
	}
}
