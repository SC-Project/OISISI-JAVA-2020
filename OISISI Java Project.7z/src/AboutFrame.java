
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JTextPane;

public class AboutFrame extends JDialog {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AboutFrame() {

		setLayout(new BorderLayout());
		
		BufferedImage myPicture;
		try {
			myPicture = ImageIO.read(new File("pictures/app.jpg"));
			JLabel picLabel = new JLabel(new ImageIcon(myPicture));
			add(picLabel, BorderLayout.NORTH);
		} catch (IOException e) {
			e.printStackTrace();
		}
		

		JTextPane text = new JTextPane();
		text.setText(
				"Aplikacija treba da prikaze prostu studentsku sluzbu gde korisnik moze da upravlja sa tri tabele (Student, "
				+ "Profesor i Predmet). Moze da dodaje, menja i brise sve elemente tabela. \n\n"
				+ "Autori: Ognjen Cosic RA205-2012 i Stefan Cosic RA99-2012"
				);
		text.setDisabledTextColor(Color.BLACK);
		text.setEnabled(false);;
		add(text, BorderLayout.CENTER);

		// Odustanak
		JButton cancel = new JButton("OK");
		cancel.setSize(50, 20);
		cancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {			
				setVisible(false);
			}
		});
		
		add(cancel, BorderLayout.SOUTH);

		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		int scrW = (int) screenSize.getWidth() / 2;
		int scrH = (int) screenSize.getHeight() / 2;

		setSize(scrW, scrH);
		setLocationRelativeTo(null); // to be on center
		setModal(true);// da ne mozes da selectujes nista dok ne zavrsis sa ovim

	}

}
