
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JTextPane;

public class HelpFrame extends JDialog {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public HelpFrame() {

		setLayout(new BorderLayout());

		JTextPane text = new JTextPane();
		text.setText(
				"Ako zelite da dodate novi entitet u neku tabelu prvo selektujete odgovarajuci tab, "
				+ "zatim selektujete neki proizvoljni red u tom tabu, pritisnete prvu opciju Menija New (Alt + N) i potom imate dve opcije: "
				+ "\n Da pritisnete prvo dugme na toolbaru. "
				+ "\n Da odete na meni i da selektujete prvu stavku (Ctrl + W) ili samo W. \n"
				+ "\n"
				+ "Ako odete New pa Close (Ctrl + C) ili samo C onda se aplikacija gasi."
				+ "\n\n"
				+ "Ako odete na drugu stavku menija Edit (Alt + E) mozete da birate da izmenite selektovani entitet (Ctrl + E) ili samo E. (Mozete i odabrati drugo dugme toolbara)\n"
				+ "Ako odete na drugu opciju Edit menija mozete da obrisete selektovanu stavku (Ctrl + D) ili samo D (Mozete i odabrati trece dugme toolbara)"
				+ "\n\n"
				+ "Ako odete na trecu stavku menija Help (Alt + H) mozete da vidite vise informacija o programu: \n"
				+ "Opcija Help (Ctrl + H) ili samo H vam otvara ovaj prozor."
				+ "Opcija About (Ctrl + A ) ili samo A vam otvara prozor o autorima i par prikaza."
				);
		text.setDisabledTextColor(Color.BLACK);
		text.setEnabled(false);;
		add(text, BorderLayout.CENTER);

		// Odustanak
		JButton cancel = new JButton("OK");
		cancel.setSize(50, 20);
		cancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {			
				setVisible(false);
			}
		});
		
		add(cancel, BorderLayout.SOUTH);

		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		int scrW = (int) screenSize.getWidth() / 2;
		int scrH = (int) screenSize.getHeight() / 2;

		setSize(scrW, scrH);
		setLocationRelativeTo(null); // to be on center
		setModal(true);// da ne mozes da selectujes nista dok ne zavrsis sa ovim

	}

}
